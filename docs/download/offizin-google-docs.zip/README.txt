Offizin 2.1.4 for Google Docs
Desktop publishing inside Google Docs: brochures, newsletters, flyers, cards,
labels, resumes, and more. By Alyssa I. Agard. https://offizin.alyssaagard.dev

WHAT IS IN THIS PACKAGE

  Code.gs          The Offizin menu and the code that builds publications.
  Sidebar.html     The Offizin panel.
  appsscript.json  The project settings. Offizin asks only for access to the
                   document it is in.
  README.txt       This guide.

Google Docs has no upload box for add-ins outside the Google Workspace
Marketplace, so these files go into a document's own Apps Script project. You
do this once, in a starter document, and then copy that document.

ADD OFFIZIN TO A DOCUMENT (about three minutes)

  1. Open a Google Doc, or a new one at docs.new. If it is pageless, choose
     File, Page setup, then Pages.
  2. Choose Extensions, then Apps Script. Rename the project Offizin.
  3. Open Code.gs, select everything, and replace it with the contents of
     Code.gs from this package.
  4. Next to Files, select the plus sign, then HTML, and name the file Sidebar.
     Replace everything in it with the contents of Sidebar.html.
  5. Open Project Settings (the gear icon), check Show "appsscript.json"
     manifest file in editor, then open appsscript.json in the editor and
     replace everything in it with the contents of appsscript.json.
  6. Save, close the Apps Script tab, and reload the document. Choose Offizin,
     then Open Offizin, and allow access when Google asks. If Google lists the
     two permissions with checkboxes, check both; Offizin needs both.

  Keep this document empty as your starter. Each time you need a publication,
  choose File, then Make a copy: Google copies Offizin along with the document.
  Each copy asks for permission the first time Offizin opens in it. Settings
  and business details stay with the document they were entered in, so save a
  brand kit once (Info tab, Save brand kit) and open it in each copy.

UPLOAD WITH CLASP (for IT teams and developers)

  Google's command line tool, clasp, can upload these files for you.
  1. Turn on the Google Apps Script API at script.google.com/home/usersettings.
  2. Install and sign in:  npm install -g @google/clasp   then   clasp login
  3. In an empty folder, create a starter document with its own project:
     clasp create --type docs --title "Offizin starter"
  4. Copy Code.gs, Sidebar.html, and appsscript.json from this package into
     that folder. If clasp made a Code.js file, delete it, and let this
     package's appsscript.json replace the one clasp made.
  5. Run  clasp push --force  and open the new document from Google Drive.

UPDATES AND HELP

  Copies made this way do not update themselves. When a new version comes out,
  paste the new files into your starter document (or run clasp push again);
  documents copied from it afterward get the new version.
  Help: https://offizin.alyssaagard.dev/support/
