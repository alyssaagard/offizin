Offizin 2.1.3 for Microsoft Word
Desktop publishing inside Word: brochures, newsletters, flyers, cards, labels,
resumes, and more. By Alyssa I. Agard. https://offizin.alyssaagard.dev

WHAT IS IN THIS PACKAGE

  offizin-manifest.xml  The add-in manifest. It tells Word where Offizin
                        lives and which buttons to add. It holds no program
                        code. Offizin has no server, no account, and no
                        tracking.
  README.txt            This guide.

Word installs add-ins from the manifest file itself. Unzip this package first,
then give Word the file offizin-manifest.xml (not the zip).

WORD ON THE WEB (personal, work, or school accounts)

  1. Open any document in Word on the web at office.com.
  2. On the Home tab, select Add-ins, then More Settings (or More Add-ins).
  3. Choose Upload My Add-in, browse to offizin-manifest.xml, and select
     Upload.
  4. The Offizin tab appears in the ribbon. Select Publications to start.

WORD FOR MAC

  1. Quit Word.
  2. In Finder, choose Go, then Go to Folder, and open this folder (create the
     wef folder if it does not exist):
     ~/Library/Containers/com.microsoft.Word/Data/Documents/wef
  3. Move offizin-manifest.xml into the wef folder.
  4. Open Word and any document. Select Home, then Add-ins, and choose Offizin.

WORD FOR WINDOWS

  Word for Windows installs single add-ins from a shared folder.
  1. Put offizin-manifest.xml in a folder, for example C:\OffizinAddin. In the
     folder's Properties, open Sharing, select Share, share it with yourself,
     and copy its network path, such as \\YOUR-PC\OffizinAddin.
  2. In Word, choose File, Options, Trust Center, Trust Center Settings, then
     Trusted Add-in Catalogs. Paste the network path into Catalog Url, select
     Add catalog, check Show in Menu, and select OK. Restart Word.
  3. Select Home, then Add-ins, then Advanced (or More Add-ins). Open Shared
     Folder, choose Offizin, and select Add.

A WHOLE ORGANIZATION (Microsoft 365 administrators)

  1. In the Microsoft 365 admin center, go to Settings, then Integrated apps.
  2. Select Upload custom apps and choose Office Add-in as the app type.
  3. Upload offizin-manifest.xml from this package, or provide the link
     https://offizin.alyssaagard.dev/word/manifest.xml instead.
  4. Choose who gets Offizin (just you, chosen groups, or everyone). Select
     Next, accept the permission request if Microsoft asks, select Next again,
     and then select Finish deployment.
  5. Offizin usually appears in Word on the web, Windows, and Mac within a day,
     but Microsoft says it can take up to 72 hours, and people may need to
     restart Word.

UPDATES AND HELP

  Word loads Offizin from https://offizin.alyssaagard.dev each time it opens, so there is nothing to
  reinstall when a new version comes out. Help: https://offizin.alyssaagard.dev/support/
